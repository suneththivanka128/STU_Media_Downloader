// STU Media Downloader — Popup Logic & Backend Integration (Firefox MV2)
// Firefox MV2 uses browserAction; provide a shim so all chrome.action calls work.
if (!chrome.action && chrome.browserAction) { chrome.action = chrome.browserAction; }

const API_BASE = "http://127.0.0.1:5000";

let isBackendOnline = false;
let currentTaskId = null;
let activeEventSource = null;
let historyCurrentPage = 1;
let scannedMediaData = null;
let currentPageReferer = ""; // Tracks the page URL (HTTP Referer) captured at badge-click time

// DOM Elements
const serverStatus = document.getElementById("serverStatus");
const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");
const serverAlert = document.getElementById("serverAlert");
const btnRetryServer = document.getElementById("btnRetryServer");

const tabButtons = document.querySelectorAll(".tab-btn");
const tabPanes = document.querySelectorAll(".tab-pane");
const queueBadge = document.getElementById("queueBadge");

const mediaUrlInput = document.getElementById("mediaUrl");
const btnPaste = document.getElementById("btnPaste");
const btnOpenInTab = document.getElementById("btnOpenInTab");
const btnScanMedia = document.getElementById("btnScanMedia");
const btnUseActiveTab = document.getElementById("btnUseActiveTab");
const scanSpinner = document.getElementById("scanSpinner");
const scanBtnText = document.getElementById("scanBtnText");

const previewCard = document.getElementById("previewCard");
const previewThumb = document.getElementById("previewThumb");
const previewTitle = document.getElementById("previewTitle");
const previewDuration = document.getElementById("previewDuration");

const formatSelect = document.getElementById("formatSelect");
const qualitySelect = document.getElementById("qualitySelect");
const connectionsSlider = document.getElementById("connectionsSlider");
const speedBadge = document.getElementById("speedBadge");
const btnStartDownload = document.getElementById("btnStartDownload");

const queueList = document.getElementById("queueList");
const emptyQueue = document.getElementById("emptyQueue");

const historySearch = document.getElementById("historySearch");
const historyFilter = document.getElementById("historyFilter");
const historyCount = document.getElementById("historyCount");
const historyList = document.getElementById("historyList");
const btnClearHistory = document.getElementById("btnClearHistory");
const btnPrevPage = document.getElementById("btnPrevPage");
const btnNextPage = document.getElementById("btnNextPage");
const pageInfo = document.getElementById("pageInfo");
const popupToast = document.getElementById("popupToast");

// Update Notification Elements
const updateBanner = document.getElementById("updateBanner");
const updateBannerTitle = document.getElementById("updateBannerTitle");
const updateBannerDesc = document.getElementById("updateBannerDesc");
const btnDismissUpdate = document.getElementById("btnDismissUpdate");
const settingEngineStatus = document.getElementById("settingEngineStatus");
const btnCheckEngineUpdate = document.getElementById("btnCheckEngineUpdate");
const engineUpdateIcon = document.getElementById("engineUpdateIcon");
const engineUpdateText = document.getElementById("engineUpdateText");
const settingAppStatus = document.getElementById("settingAppStatus");
const btnCheckAppUpdate = document.getElementById("btnCheckAppUpdate");
const appUpdateIcon = document.getElementById("appUpdateIcon");
const appUpdateText = document.getElementById("appUpdateText");

let currentAppVersion = "1.0.2";
let isDevEnvironment = false;

// Settings Elements
const settingConcurrent = document.getElementById("settingConcurrent");
const settingConnections = document.getElementById("settingConnections");
const settingFormat = document.getElementById("settingFormat");
const settingQuality = document.getElementById("settingQuality");
const settingDownloadDir = document.getElementById("settingDownloadDir");
const settingDownloadDirText = document.getElementById("settingDownloadDirText");
const settingCustomDirDisplay = document.getElementById("settingCustomDirDisplay");
const btnBrowseFolder = document.getElementById("btnBrowseFolder");
const btnResetFolder = document.getElementById("btnResetFolder");
const btnOpenDownloadsFolder = document.getElementById("btnOpenDownloadsFolder");
const settingServerStatus = document.getElementById("settingServerStatus");
const btnShutdownServer = document.getElementById("btnShutdownServer");
const btnSaveSettings = document.getElementById("btnSaveSettings");

// Detected HLS Streams panel elements
const detectedStreamsPanel = document.getElementById("detectedStreamsPanel");
const detectedStreamsList = document.getElementById("detectedStreamsList");
const btnClearStreams = document.getElementById("btnClearStreams");

// Settings Overlay
const settingsPanel   = document.getElementById("settingsPanel");
const btnToggleSettings = document.getElementById("btnToggleSettings");
const btnCloseSettings  = document.getElementById("btnCloseSettings");

// Torrent & FTP Tab
const torrentUrlInput  = document.getElementById("torrentUrlInput");
const torrentTypeBadge = document.getElementById("torrentTypeBadge");
const torrentEngineBadge = document.getElementById("torrentEngineBadge");
const torrentInfoCard  = document.getElementById("torrentInfoCard");
const torrentInfoIcon  = document.getElementById("torrentInfoIcon");
const torrentInfoName  = document.getElementById("torrentInfoName");
const torrentInfoMeta  = document.getElementById("torrentInfoMeta");
const torrentCustomName = document.getElementById("torrentCustomName");
const btnTorrentDownload = document.getElementById("btnTorrentDownload");
const btnTorrentPaste   = document.getElementById("btnTorrentPaste");
const btnTorrentFile    = document.getElementById("btnTorrentFile");
const torrentFileInput  = document.getElementById("torrentFileInput");
const torrentBtnText    = document.getElementById("torrentBtnText");




// ============================================================
// 1. INITIALIZATION & SERVER STATUS
// ============================================================

document.addEventListener("DOMContentLoaded", async () => {
  if (window.location.search.includes("mode=tab") || window.innerWidth > 520) {
    document.body.classList.add("standalone-tab");
  }
  setupTabs();
  setupEventListeners();
  setupSettingsOverlay();
  setupTorrentTab();
  // Health check runs lazily (when ⚙️ settings panel opens).
  // But we still need a quick silent ping so download actions work correctly.
  checkServerHealth().catch(() => {});
  await loadAndApplySettings();
  await initializeMediaInput();
  await restoreActiveQueue();
  await loadDetectedStreams();
});

async function checkServerHealth() {
  try {
    const res = await fetch(`${API_BASE}/health`, { method: "GET", signal: AbortSignal.timeout(3000) });
    if (res.ok) {
      const data = await res.json();
      isBackendOnline = true;
      if (statusDot) statusDot.className = "status-dot online";
      if (statusText) statusText.textContent = "Online";
      if (serverAlert) serverAlert.classList.add("hidden");

      if (data.ytdlp_update) {
        handleYtdlpUpdateNotice(data.ytdlp_update);
      }
      if (data.app_version) {
        currentAppVersion = data.app_version;
        isDevEnvironment = Boolean(data.is_dev);
        handleAppVersionNotice(data.app_version, data.is_dev);
      }
      if (settingServerStatus) settingServerStatus.textContent = "Server active on port 5000";
      if (btnShutdownServer) btnShutdownServer.disabled = false;
      if (btnCheckAppUpdate) btnCheckAppUpdate.disabled = false;
      return true;
    }
  } catch (err) {
    // Offline
  }
  isBackendOnline = false;
  if (statusDot) statusDot.className = "status-dot offline";
  if (statusText) statusText.textContent = "Offline";
  if (serverAlert) serverAlert.classList.remove("hidden");
  if (settingServerStatus) settingServerStatus.textContent = "Server is offline";
  if (settingAppStatus) settingAppStatus.textContent = "Server offline";
  if (btnShutdownServer) btnShutdownServer.disabled = true;
  if (btnCheckAppUpdate) btnCheckAppUpdate.disabled = true;
  return false;
}

function handleAppVersionNotice(version, isDev) {
  if (!settingAppStatus) return;
  if (isDev) {
    settingAppStatus.textContent = `v${version} • Development Mode`;
  } else {
    settingAppStatus.textContent = `v${version} • Production`;
  }
}

function handleYtdlpUpdateNotice(info) {
  if (!info) return;

  if (settingEngineStatus) {
    if (info.version && info.version !== "unknown") {
      settingEngineStatus.textContent = `v${info.version} • ${info.updated ? "Updated" : "Up to date"}`;
    } else if (info.message) {
      settingEngineStatus.textContent = info.message;
    }
  }

  if (info.updated && updateBanner) {
    updateBannerTitle.textContent = "⚡ Media Engine Updated!";
    updateBannerDesc.textContent = info.message || `Media extractor updated to ${info.version}`;
    updateBanner.classList.remove("hidden");
    showToast(`🎉 Media Extractor Engine updated to v${info.version}! Latest extractors loaded.`, 5000);
  }
}

function setupSettingsSubtabs() {
  const subtabBtns = document.querySelectorAll(".subtab-btn");
  subtabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-subtab");
      subtabBtns.forEach((b) => b.classList.toggle("active", b === btn));
      document.querySelectorAll(".subtab-pane").forEach((pane) => {
        pane.classList.toggle("hidden", pane.id !== targetId);
      });
    });
  });
}

function showToast(message, duration = 3000) {
  popupToast.textContent = message;
  popupToast.classList.remove("hidden");
  setTimeout(() => popupToast.classList.add("hidden"), duration);
}

function highlightEmptyInput(inputEl, message) {
  if (inputEl) {
    inputEl.classList.add("input-error");
    inputEl.focus();
    setTimeout(() => inputEl.classList.remove("input-error"), 1500);
  }
  showToast(message || "⚠️ Please enter a URL first");
}

// ============================================================
// 2. TAB NAVIGATION
// ============================================================

function setupTabs() {
  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-tab");
      switchTab(targetId);
    });
  });
}

function switchTab(targetId) {
  tabButtons.forEach((b) => b.classList.toggle("active", b.getAttribute("data-tab") === targetId));
  tabPanes.forEach((p) => p.classList.toggle("active", p.id === targetId));

  if (targetId === "tab-history") {
    loadHistory(historyCurrentPage);
  } else if (targetId === "tab-media") {
    loadDetectedStreams();
  }
}

// ============================================================
// 3. MEDIA TAB & SCAN HANDLING
// ============================================================

async function initializeMediaInput() {
  if (!chrome || !chrome.storage || !chrome.storage.local) return;

  // Get the active tab first — we need it to do per-tab stream lookup
  let activeTab = null;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTab = tab || null;
  } catch (_) {}

  chrome.storage.local.get(["detectedMedia", "detectedM3u8", "pageUrl"], (res) => {

    // ── Priority 1: badge click from content.js overlay ─────────────────────
    if (res.detectedMedia) {
      const dm = res.detectedMedia;

      // ── HLS/blob page (vixeo.io etc.) ─────────────────────────────────────
      // blob: URL → real stream is in .ts/.m3u8 network requests (background.js).
      // Check per-tab streams first. If found → M3U8 mode immediately.
      // If NOT found → fall back to scanning the page URL (yt-dlp may handle it,
      // e.g. YouTube, Vimeo). The HLS wait message only shows if the scan also fails.
      if (dm.isHLSPage) {
        chrome.storage.local.remove(["detectedMedia"]);
        currentPageReferer = dm.pageUrl || "";

        if (activeTab && activeTab.id) {
          const tabKey = `streams_tab_${activeTab.id}`;
          chrome.storage.local.get([tabKey], (tabRes) => {
            const streams = Array.isArray(tabRes[tabKey]) ? tabRes[tabKey] : [];
            const fresh   = streams.filter((s) => Date.now() - (s.timestamp || 0) < 30 * 60 * 1000);

            if (fresh.length > 0) {
              // ✅ Streams captured → use M3U8 directly
              mediaUrlInput.value = fresh[0].url;
              currentPageReferer  = fresh[0].pageUrl || currentPageReferer;
              triggerScan(fresh[0].url);
              renderDetectedStreams(streams, activeTab.id);
            } else {
              // ⬇ No streams yet → try scanning the page URL (YouTube etc. work via yt-dlp)
              // If that scan also fails, triggerScan will call showHLSWaitMessage automatically.
              const pageUrl = dm.pageUrl || "";
              if (pageUrl) {
                mediaUrlInput.value = pageUrl;
                triggerScan(pageUrl);
              }
            }
          });
        } else {
          // No tab info — just scan the page URL
          const pageUrl = dm.pageUrl || "";
          if (pageUrl) {
            mediaUrlInput.value = pageUrl;
            triggerScan(pageUrl);
          }
        }
        return;
      }

      // ── Normal page with a real media URL ─────────────────────────────────
      let candidate = dm.url || "";
      if (candidate.startsWith("blob:") || candidate.startsWith("data:")) {
        candidate = dm.pageUrl || "";
      }
      if (dm.pageUrl) currentPageReferer = dm.pageUrl;

      if (candidate && (Date.now() - (dm.timestamp || 0) < 300000)) {
        mediaUrlInput.value = candidate;
        triggerScan(candidate);
        chrome.storage.local.remove(["detectedMedia"]);
        return;
      } else {
        chrome.storage.local.remove(["detectedMedia"]);
        currentPageReferer = "";
      }
    }

    // ── Priority 2: per-tab stream captured by background.js webRequest ──────
    // Use per-tab storage (keyed by tab ID) so we never show a stream from a
    // different tab. Falls back to global detectedM3u8 only if same hostname.
    if (activeTab && activeTab.id) {
      const tabKey = `streams_tab_${activeTab.id}`;
      chrome.storage.local.get([tabKey], (tabRes) => {
        const streams = Array.isArray(tabRes[tabKey]) ? tabRes[tabKey] : [];
        // Take the most recent fresh stream (< 30 min old)
        const fresh = streams.find((s) => Date.now() - (s.timestamp || 0) < 30 * 60 * 1000);

        if (fresh) {
          mediaUrlInput.value = fresh.url;
          currentPageReferer = fresh.pageUrl || "";
          triggerScan(fresh.url);
          return;
        }

        // ── Fallback: global detectedM3u8 (only if same tab hostname) ────────
        if (res.detectedM3u8 && res.pageUrl) {
          let sameSite = false;
          try {
            sameSite = activeTab.url &&
              new URL(res.pageUrl).hostname === new URL(activeTab.url).hostname;
          } catch (_) {}

          if (sameSite) {
            mediaUrlInput.value = res.detectedM3u8;
            currentPageReferer = res.pageUrl;
            triggerScan(res.detectedM3u8);
          }
        }
      });
    } else if (res.detectedM3u8) {
      // No active tab info available — use global key as last resort
      mediaUrlInput.value = res.detectedM3u8;
      currentPageReferer = res.pageUrl || "";
      triggerScan(res.detectedM3u8);
    }
  });
}

// ============================================================
// 3b. HLS WAIT MESSAGE (blob-URL video — stream not yet captured)
// ============================================================

/**
 * Show a friendly instruction card when the user clicked the ⚡ badge on a
 * blob-URL video (HLS/MSE stream) but background.js hasn't captured any
 * .ts/.m3u8 requests yet (video hasn't started playing).
 * @param {string} pageUrl - The page URL (shown as context)
 */
function showHLSWaitMessage(pageUrl) {
  let host = "";
  try { host = pageUrl ? new URL(pageUrl).hostname : ""; } catch (_) {}

  // Show the preview card as an instruction panel
  if (previewThumb)    previewThumb.src = "icons/icon-128.png";
  if (previewTitle)    previewTitle.textContent = "HLS Stream — Play Video First";
  if (previewDuration) previewDuration.textContent = host ? `🌐 ${host}` : "Streaming site";
  if (previewSource) {
    previewSource.textContent = "⚠️ Waiting";
    previewSource.className   = "badge badge-warn";
  }
  if (previewCard) previewCard.classList.remove("hidden");

  // Show the streams panel in "empty + hint" mode
  if (detectedStreamsPanel && detectedStreamsList) {
    detectedStreamsPanel.classList.remove("hidden");
    detectedStreamsList.innerHTML = `
      <div style="padding:10px 4px;color:#94a3b8;font-size:11px;line-height:1.6;">
        <strong style="color:#f59e0b;">⚠️ Stream not detected yet.</strong><br>
        Follow these steps:<br>
        <span style="color:#10b981;">①</span> Close this popup<br>
        <span style="color:#10b981;">②</span> Press <strong>Play</strong> on the video<br>
        <span style="color:#10b981;">③</span> Wait 2–3 seconds<br>
        <span style="color:#10b981;">④</span> Click the extension icon again
      </div>
    `;
  }

  showToast("▶️ Play the video first, then re-open the extension!", 5000);
}


/**
 * Load M3U8 URLs intercepted by background.js for the active tab and
 * render them in the Detected Streams panel.
 */
async function loadDetectedStreams() {
  if (!chrome || !chrome.tabs || !chrome.storage) return;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return;

    const key = `streams_tab_${tab.id}`;
    chrome.storage.local.get([key], (result) => {
      const streams = Array.isArray(result[key]) ? result[key] : [];
      renderDetectedStreams(streams, tab.id);

      // Clear the "HLS" badge now that the user has opened the popup
      try {
        chrome.action.setBadgeText({ text: "", tabId: tab.id });
      } catch (_) {
        chrome.action.setBadgeText({ text: "" });
      }
    });
  } catch (e) {
    console.warn("loadDetectedStreams error:", e);
  }
}

/**
 * Render the list of detected M3U8 streams into the panel.
 * @param {Array} streams - Array of { url, pageUrl, pageTitle, timestamp }
 * @param {number} tabId - Active tab ID (used for clearing storage)
 */
function renderDetectedStreams(streams, tabId) {
  if (!detectedStreamsPanel || !detectedStreamsList) return;

  // Filter out stale entries older than 30 minutes
  const fresh = streams.filter((s) => Date.now() - (s.timestamp || 0) < 30 * 60 * 1000);

  if (fresh.length === 0) {
    detectedStreamsPanel.classList.add("hidden");
    return;
  }

  detectedStreamsPanel.classList.remove("hidden");
  detectedStreamsList.innerHTML = "";

  fresh.forEach((stream, idx) => {
    const item = document.createElement("div");
    item.className = "detected-stream-item";

    // Shorten the URL for display
    let displayUrl = stream.url;
    try {
      const u = new URL(stream.url);
      displayUrl = u.pathname.split("/").slice(-2).join("/") + (u.search ? "?..." : "");
    } catch (_) {}

    let originHost = "";
    try { originHost = new URL(stream.pageUrl).hostname; } catch (_) {}

    item.innerHTML = `
      <span class="detected-stream-icon">📡</span>
      <div class="detected-stream-info">
        <div class="detected-stream-label" title="${escapeHtml(stream.url)}">${escapeHtml(displayUrl)}</div>
        ${originHost ? `<div class="detected-stream-origin">🌐 ${escapeHtml(originHost)}</div>` : ""}
      </div>
      <button class="btn-use-stream" data-idx="${idx}">⚡ Use</button>
    `;

    item.querySelector(".btn-use-stream").addEventListener("click", () => {
      useDetectedStream(stream);
    });

    detectedStreamsList.appendChild(item);
  });

  // Wire up the Clear button
  if (btnClearStreams) {
    btnClearStreams.onclick = () => {
      if (tabId) {
        chrome.storage.local.remove([`streams_tab_${tabId}`, "detectedM3u8", "pageUrl"]);
        try { chrome.action.setBadgeText({ text: "", tabId: tabId }); } catch (_) {
          chrome.action.setBadgeText({ text: "" });
        }
      }
      detectedStreamsPanel.classList.add("hidden");
      detectedStreamsList.innerHTML = "";
      showToast("Detected streams cleared");
    };
  }
}

/**
 * Pre-fill the Media tab with a detected stream URL and its referer,
 * then trigger the HLS detection path in triggerScan().
 */
function useDetectedStream(stream) {
  mediaUrlInput.value = stream.url;
  currentPageReferer = stream.pageUrl || "";
  triggerScan(stream.url);
  // Clear the badge — user has acknowledged the capture
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab) chrome.action.setBadgeText({ text: "", tabId: tab.id });
    });
  } catch (_) {
    chrome.action.setBadgeText({ text: "" });
  }
  let host = "";
  try { host = new URL(stream.pageUrl).hostname; } catch (_) {}
  showToast(`⚡ HLS stream loaded${host ? " from " + host : ""}`);
}

async function fetchActiveTabUrl() {
  try {
    if (chrome && chrome.tabs) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && (tab.url.startsWith("http://") || tab.url.startsWith("https://"))) {
        mediaUrlInput.value = tab.url;
        showToast("Active tab URL loaded ⚡ Scanning...");
        triggerScan(tab.url);
      } else {
        showToast("No valid web URL found in current tab");
      }
    } else {
      showToast("Cannot access browser tabs");
    }
  } catch (e) {
    console.warn("Could not query active tab:", e);
    showToast("Unable to fetch current tab URL");
  }
}

function setupEventListeners() {
  setupSettingsSubtabs();
  btnRetryServer.addEventListener("click", async () => {
    const ok = await checkServerHealth();
    if (ok) {
      showToast("Connected to STU Downloader backend! ⚡");
      loadAndApplySettings();
    }
  });

  /**
   * Cross-platform, OS-aware clipboard reader.
   * Tier 1: Modern navigator.clipboard.readText() (enabled via "clipboardRead" in manifest)
   * Tier 2: document.execCommand('paste') via focused offscreen textarea fallback
   * Tier 3: Native OS clipboard bridge via backend GET /clipboard (Linux Wayland/X11, macOS, Windows)
   */
  async function readClipboardText() {
    // 1. Try browser async clipboard API
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const clip = await navigator.clipboard.readText();
        if (clip && clip.trim()) {
          return clip.trim();
        }
      }
    } catch (err) {
      console.warn("navigator.clipboard.readText error (trying fallback):", err);
    }

    // 2. Try document.execCommand('paste') via an offscreen probe element
    try {
      const prevFocused = document.activeElement;
      const probe = document.createElement("textarea");
      probe.setAttribute("aria-hidden", "true");
      probe.classList.add("hidden");
      document.body.appendChild(probe);
      probe.focus();
      const success = document.execCommand("paste");
      const val = probe.value;
      document.body.removeChild(probe);
      if (prevFocused && typeof prevFocused.focus === "function") {
        prevFocused.focus();
      }
      if (success && val && val.trim()) {
        return val.trim();
      }
    } catch (err) {
      console.warn("document.execCommand paste failed (trying OS bridge):", err);
    }

    // 3. Try OS-level clipboard from local backend (Wayland, X11, macOS, Windows)
    if (isBackendOnline) {
      try {
        const res = await fetch(`${API_BASE}/clipboard`);
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.text && data.text.trim()) {
            return data.text.trim();
          }
        }
      } catch (err) {
        console.warn("Backend /clipboard fetch failed:", err);
      }
    }

    return "";
  }

  // Paste from clipboard — cross-platform & OS-aware
  btnPaste.addEventListener("click", async () => {
    btnPaste.disabled = true;
    try {
      const text = await readClipboardText();
      if (text) {
        mediaUrlInput.value = text;
        mediaUrlInput.focus();
        showToast("URL pasted! Click 'Scan Media' or press Enter 🔍");
      } else {
        showToast("📋 Clipboard is empty or no text found");
      }
    } catch (e) {
      showToast("⚠️ Unable to read clipboard");
    } finally {
      btnPaste.disabled = false;
    }
  });

  // Enter key triggers scan manually
  mediaUrlInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const url = mediaUrlInput.value.trim();
      if (url) {
        triggerScan(url);
      } else {
        showToast("Please enter or paste a media URL first");
      }
    }
  });

  // Current Tab button — explicitly scans current tab
  btnUseActiveTab.addEventListener("click", () => {
    fetchActiveTabUrl();
  });

  // Manual Scan button
  btnScanMedia.addEventListener("click", () => {
    const url = mediaUrlInput ? mediaUrlInput.value.trim() : "";
    if (!url) {
      highlightEmptyInput(mediaUrlInput, "⚠️ Please enter a media URL first!");
      return;
    }
    triggerScan(url);
  });

  connectionsSlider.addEventListener("input", (e) => {
    const val = e.target.value;
    speedBadge.textContent = `⚡ ${val}x Connections`;
  });

  btnStartDownload.addEventListener("click", startDownload);

  // History Event Listeners
  historySearch.addEventListener("input", debounce(() => loadHistory(1), 300));
  historyFilter.addEventListener("change", () => loadHistory(1));
  btnClearHistory.addEventListener("click", clearAllHistory);
  btnPrevPage.addEventListener("click", () => {
    if (historyCurrentPage > 1) loadHistory(historyCurrentPage - 1);
  });
  btnNextPage.addEventListener("click", () => {
    loadHistory(historyCurrentPage + 1);
  });

  // Settings Save & Open Folder Listener
  btnSaveSettings.addEventListener("click", saveSettings);
  if (btnOpenDownloadsFolder) {
    btnOpenDownloadsFolder.addEventListener("click", () => openFolder(""));
  }

  // Open Extension in Dedicated Tab
  if (btnOpenInTab) {
    btnOpenInTab.addEventListener("click", () => {
      const tabUrl = (typeof chrome !== "undefined" && chrome.runtime) ? chrome.runtime.getURL("popup.html?mode=tab") : "popup.html?mode=tab";
      if (typeof chrome !== "undefined" && chrome.tabs && typeof chrome.tabs.create === "function") {
        chrome.tabs.create({ url: tabUrl });
      } else {
        window.open(tabUrl, "_blank");
      }
    });
  }

  // Native OS Folder Picker
  if (btnBrowseFolder) {
    btnBrowseFolder.addEventListener("click", async () => {
      if (!isBackendOnline) {
        const ok = await checkServerHealth();
        if (!ok) {
          showToast("⚠️ Backend offline — start STU Downloader server first");
          return;
        }
      }
      const prevHtml = btnBrowseFolder.innerHTML;
      btnBrowseFolder.innerHTML = "⏳ Choosing...";
      btnBrowseFolder.disabled = true;
      showToast("📁 Folder picker opened! Selection auto-saves on backend.", 4000);
      try {
        const currentDir = settingDownloadDir ? settingDownloadDir.value.trim() : "";
        const res = await fetch(`${API_BASE}/pick-folder`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ current_dir: currentDir }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.path) {
            if (settingDownloadDir) settingDownloadDir.value = data.path;
            if (settingCustomDirDisplay) {
              settingCustomDirDisplay.textContent = data.path;
              settingCustomDirDisplay.title = data.path;
            }
            if (settingDownloadDirText) {
              settingDownloadDirText.textContent = data.path;
              settingDownloadDirText.title = data.path;
            }
            if (btnResetFolder) btnResetFolder.classList.remove("hidden");
            await saveSettings();
            const folderName = data.path.split(/[/\\]/).filter(Boolean).pop() || data.path;
            showToast(`📁 Download folder set: ${folderName}`);
          } else if (data.canceled) {
            // User cancelled dialog
          } else if (data.error) {
            showToast(`⚠️ ${data.error}`);
          }
        } else {
          showToast("⚠️ Could not open folder selection");
        }
      } catch (e) {
        console.error("Folder picker request error:", e);
      } finally {
        btnBrowseFolder.innerHTML = prevHtml;
        btnBrowseFolder.disabled = false;
      }
    });
  }

  if (btnResetFolder) {
    btnResetFolder.addEventListener("click", async () => {
      if (settingDownloadDir) settingDownloadDir.value = "";
      if (settingCustomDirDisplay) {
        settingCustomDirDisplay.textContent = "Default: System Downloads";
        settingCustomDirDisplay.title = "Default: System Downloads";
      }
      if (settingDownloadDirText) {
        settingDownloadDirText.textContent = "System Downloads";
        settingDownloadDirText.title = "System Downloads";
      }
      btnResetFolder.classList.add("hidden");
      await saveSettings();
      showToast("↺ Restored default Downloads folder");
    });
  }

  // Engine Update Listeners
  if (btnDismissUpdate) {
    btnDismissUpdate.addEventListener("click", () => {
      if (updateBanner) updateBanner.classList.add("hidden");
      fetch(`${API_BASE}/dismiss-update-notification`, { method: "POST" }).catch(() => {});
    });
  }

  if (btnCheckAppUpdate) {
    btnCheckAppUpdate.addEventListener("click", checkAppUpdate);
  }

  if (btnCheckEngineUpdate) {
    btnCheckEngineUpdate.addEventListener("click", checkEngineUpdate);
  }

  // Server Shutdown Listener
  if (btnShutdownServer) {
    btnShutdownServer.addEventListener("click", shutdownBackendServer);
  }
}

// ── Settings overlay panel ──────────────────────────────────────────────────
function setupSettingsOverlay() {
  if (btnToggleSettings) {
    btnToggleSettings.addEventListener("click", () => {
      const isHidden = settingsPanel.classList.contains("hidden");
      if (isHidden) {
        openSettingsPanel();
      } else {
        closeSettingsPanel();
      }
    });
  }
  if (btnCloseSettings) {
    btnCloseSettings.addEventListener("click", closeSettingsPanel);
  }
  // Close on outside click
  document.addEventListener("click", (e) => {
    if (
      settingsPanel &&
      !settingsPanel.classList.contains("hidden") &&
      !settingsPanel.contains(e.target) &&
      e.target !== btnToggleSettings
    ) {
      closeSettingsPanel();
    }
  });
}

async function openSettingsPanel() {
  if (!settingsPanel) return;
  settingsPanel.classList.remove("hidden");
  if (btnToggleSettings) btnToggleSettings.classList.add("active");
  // Run health check + settings load when panel first opens
  await checkServerHealth().catch(() => {});
  await loadAndApplySettings();
}

function closeSettingsPanel() {
  if (!settingsPanel) return;
  settingsPanel.classList.add("hidden");
  if (btnToggleSettings) btnToggleSettings.classList.remove("active");
}

// ── Torrent & FTP Tab ────────────────────────────────────────────────────────
function detectTorrentType(url) {
  if (!url) return null;
  const u = url.trim().toLowerCase();
  if (u.startsWith("magnet:") || u.endsWith(".torrent")) return "torrent";
  if (u.startsWith("ftp://") || u.startsWith("sftp://")) return "ftp";
  if (u.startsWith("http://") || u.startsWith("https://")) return "direct";
  return null;
}

function updateTorrentUI(url) {
  const type = detectTorrentType(url);
  if (!type) {
    if (torrentTypeBadge) torrentTypeBadge.classList.add("hidden");
    if (torrentEngineBadge) torrentEngineBadge.classList.add("hidden");
    if (torrentInfoCard) torrentInfoCard.classList.add("hidden");
    if (btnTorrentDownload) {
      btnTorrentDownload.disabled = false;
      if (torrentBtnText) torrentBtnText.textContent = "🧲 Start Download";
    }
    return;
  }

  // Type badge
  if (torrentTypeBadge) {
    torrentTypeBadge.className = `torrent-type-badge type-${type}`;
    const labels = {
      torrent: "🧲 Torrent — BitTorrent Protocol",
      ftp:     "📡 FTP — Direct Server Path",
      direct:  "🔗 Direct HTTP — Multi-Threaded",
    };
    torrentTypeBadge.textContent = labels[type];
    torrentTypeBadge.classList.remove("hidden");
  }

  // Engine badge
  if (torrentEngineBadge) {
    torrentEngineBadge.classList.remove("hidden");
    if (type === "torrent") {
      torrentEngineBadge.textContent = "⚡ BitTorrent Protocol Enabled";
    } else if (type === "ftp") {
      torrentEngineBadge.textContent = "⚡ FTP Protocol Enabled";
    } else {
      torrentEngineBadge.textContent = "⚡ Multi-Thread Acceleration (16x)";
    }
  }

  // Info card
  if (torrentInfoIcon) {
    const icons = { torrent: "🧲", ftp: "📡", direct: "🔗" };
    torrentInfoIcon.textContent = icons[type];
  }

  let name = "";
  let meta = "";
  if (type === "torrent" && url.startsWith("magnet:")) {
    try {
      const qs = new URLSearchParams(url.slice(url.indexOf("?") + 1));
      name = qs.get("dn") || "Torrent (name unknown)";
      const trackers = qs.getAll("tr").length;
      meta = trackers ? `${trackers} tracker(s)` : "BitTorrent Network";
    } catch (_) { name = "Magnet Link"; }
  } else {
    try {
      const u = url.split("?")[0];
      name = u.split("/").filter(Boolean).pop() || url;
      meta = url.split("/")[2] || "";
    } catch (_) { name = url; }
  }

  if (torrentInfoName) torrentInfoName.textContent = name;
  if (torrentInfoMeta) torrentInfoMeta.textContent = meta;
  if (torrentInfoCard) torrentInfoCard.classList.remove("hidden");
  if (btnTorrentDownload) btnTorrentDownload.disabled = false;

  const btnLabels = { torrent: "🧲 Download Torrent", ftp: "📡 Download via FTP", direct: "🔗 Download Direct" };
  if (torrentBtnText) torrentBtnText.textContent = btnLabels[type];
}

function setupTorrentTab() {
  if (torrentUrlInput) {
    torrentUrlInput.addEventListener("input", () => updateTorrentUI(torrentUrlInput.value.trim()));
    torrentUrlInput.addEventListener("paste", (e) => {
      setTimeout(() => updateTorrentUI(torrentUrlInput.value.trim()), 50);
    });
  }

  if (btnTorrentFile && torrentFileInput) {
    btnTorrentFile.addEventListener("click", () => torrentFileInput.click());
    torrentFileInput.addEventListener("change", (e) => {
      const file = e.target.files && e.target.files[0];
      if (file) {
        if (torrentUrlInput) {
          torrentUrlInput.value = file.name;
          updateTorrentUI(file.name);
        }
        showToast(`📁 Selected torrent file: ${file.name}`);
      }
    });
  }

  if (btnTorrentPaste) {
    btnTorrentPaste.addEventListener("click", async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (text && torrentUrlInput) {
          torrentUrlInput.value = text.trim();
          updateTorrentUI(text.trim());
        }
      } catch (_) {
        try {
          const res = await fetch(`${API_BASE}/clipboard`);
          if (res.ok) {
            const d = await res.json();
            if (d.text && torrentUrlInput) {
              torrentUrlInput.value = d.text.trim();
              updateTorrentUI(d.text.trim());
            }
          }
        } catch (_2) {}
      }
    });
  }

  if (btnTorrentDownload) {
    btnTorrentDownload.addEventListener("click", startAriaDownload);
  }
}

async function startAriaDownload() {
  const url = torrentUrlInput ? torrentUrlInput.value.trim() : "";
  if (!url) {
    highlightEmptyInput(torrentUrlInput, "⚠️ Enter a Magnet/FTP URL or select a .torrent file first!");
    return;
  }

  if (!isBackendOnline) {
    const ok = await checkServerHealth();
    if (!ok) {
      showToast("Backend offline — please start the server first");
      return;
    }
  }

  const customTitle = torrentCustomName ? torrentCustomName.value.trim() : "";
  btnTorrentDownload.disabled = true;
  if (torrentBtnText) torrentBtnText.textContent = "⏳ Starting...";

  try {
    const res = await fetch(`${API_BASE}/aria2-download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, title: customTitle }),
    });

    if (res.ok) {
      const data = await res.json();
      showToast(`⚡ Download queued! Tracking live progress...`);
      if (torrentUrlInput) torrentUrlInput.value = "";
      if (torrentCustomName) torrentCustomName.value = "";
      if (torrentTypeBadge) torrentTypeBadge.classList.add("hidden");
      if (torrentEngineBadge) torrentEngineBadge.classList.add("hidden");
      if (torrentInfoCard) torrentInfoCard.classList.add("hidden");

      const taskTitle = customTitle || "Torrent Download";
      currentTaskId = data.task_id;
      const storageObj = typeof browser !== "undefined" && browser.storage ? browser.storage.local : (chrome && chrome.storage ? chrome.storage.local : null);
      if (storageObj) {
        storageObj.set({ activeTask: { taskId: currentTaskId, title: taskTitle } });
      }

      // Switch to Queue tab so download progress is tracked only in Queue
      switchTab("tab-queue");

      // Start SSE progress tracking
      listenToProgressStream(data.task_id, taskTitle);
    } else {
      const err = await res.json().catch(() => ({}));
      showToast(err.error || "Failed to start download ⚠️");
    }
  } catch (e) {
    console.error("Error starting torrent download:", e);
    showToast(e.name === "TypeError" ? "Network error — is the backend running?" : `Error: ${e.message}`);
  } finally {
    btnTorrentDownload.disabled = false;
    updateTorrentUI(torrentUrlInput ? torrentUrlInput.value.trim() : "");
  }
}

async function shutdownBackendServer() {
  if (!isBackendOnline) {
    showToast("Server is already offline");
    return;
  }

  const confirmed = confirm("Are you sure you want to stop the STU Media Downloader backend server?");
  if (!confirmed) return;

  try {
    const res = await fetch(`${API_BASE}/shutdown`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ force: false }),
    });

    if (res.status === 409) {
      const forceConfirm = confirm("⚠️ Downloads are currently in progress! Do you want to force stop the server anyway?");
      if (forceConfirm) {
        await fetch(`${API_BASE}/shutdown`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ force: true }),
        });
      } else {
        return;
      }
    }

    isBackendOnline = false;
    if (statusDot) statusDot.className = "status-dot offline";
    if (statusText) statusText.textContent = "Offline";
    if (serverAlert) serverAlert.classList.remove("hidden");
    if (settingServerStatus) settingServerStatus.textContent = "Server is offline";
    if (btnShutdownServer) btnShutdownServer.disabled = true;
    showToast("🛑 STU Downloader backend stopped successfully");
  } catch (e) {
    isBackendOnline = false;
    if (statusDot) statusDot.className = "status-dot offline";
    if (statusText) statusText.textContent = "Offline";
    if (serverAlert) serverAlert.classList.remove("hidden");
    if (settingServerStatus) settingServerStatus.textContent = "Server is offline";
    if (btnShutdownServer) btnShutdownServer.disabled = true;
    showToast("🛑 Backend server stopped");
  }
}

async function checkAppUpdate() {
  if (!isBackendOnline) {
    const ok = await checkServerHealth();
    if (!ok) {
      showToast("Backend offline — please start backend server first");
      return;
    }
  }

  if (appUpdateIcon) appUpdateIcon.classList.add("btn-icon-spin");
  if (appUpdateText) appUpdateText.textContent = "Checking...";
  if (btnCheckAppUpdate) btnCheckAppUpdate.disabled = true;

  try {
    const res = await fetch(`${API_BASE}/check-app-update`, { method: "POST" });
    if (res.ok) {
      const data = await res.json();
      if (data.is_dev) {
        if (settingAppStatus) settingAppStatus.textContent = `v${data.current_version} • Development Mode`;
        showToast("ℹ️ Development mode active — update checks disabled.", 4000);
      } else if (data.update_available) {
        const updateVer = data.latest_version ? `v${data.latest_version}` : (data.latest_sha || "latest");
        if (settingAppStatus) settingAppStatus.textContent = `Update available: ${updateVer}`;
        const userAction = confirm(`🚀 New STU Downloader update available (${updateVer})!\n\n${data.message || ""}\n\nDo you want to open the GitHub update page?`);
        if (userAction && data.release_url) {
          window.open(data.release_url, "_blank");
        }
      } else {
        if (settingAppStatus) settingAppStatus.textContent = `v${data.current_version} • Up to date`;
        showToast(`✅ STU Downloader is up to date (v${data.current_version})!`, 4000);
      }
    } else {
      showToast("⚠️ Could not check for STU Downloader updates");
    }
  } catch (err) {
    console.error("Check app update error:", err);
    showToast("⚠️ Network error while checking app updates");
  } finally {
    if (appUpdateIcon) appUpdateIcon.classList.remove("btn-icon-spin");
    if (appUpdateText) appUpdateText.textContent = "Check Update";
    if (btnCheckAppUpdate) btnCheckAppUpdate.disabled = false;
  }
}

async function checkEngineUpdate() {
  if (!isBackendOnline) {
    const ok = await checkServerHealth();
    if (!ok) {
      showToast("Backend offline — please start backend server first");
      return;
    }
  }

  if (engineUpdateIcon) engineUpdateIcon.classList.add("btn-icon-spin");
  if (engineUpdateText) engineUpdateText.textContent = "Checking...";
  if (btnCheckEngineUpdate) btnCheckEngineUpdate.disabled = true;

  try {
    const res = await fetch(`${API_BASE}/check-updates`, { method: "POST" });
    if (res.ok) {
      const info = await res.json();
      handleYtdlpUpdateNotice(info);
      if (info.updated) {
        showToast(`🎉 Extractor engine updated to ${info.version}! Latest extractors loaded ⚡`, 5000);
      } else {
        showToast(`✅ Extractor engine is up to date (${info.version})!`, 4000);
      }
    } else {
      showToast("⚠️ Could not check for updates");
    }
  } catch (err) {
    console.error("Check update error:", err);
    showToast("⚠️ Network error while checking updates");
  } finally {
    if (engineUpdateIcon) engineUpdateIcon.classList.remove("btn-icon-spin");
    if (engineUpdateText) engineUpdateText.textContent = "Check Update";
    if (btnCheckEngineUpdate) btnCheckEngineUpdate.disabled = false;
  }
}

async function triggerScan(url) {
  if (!url || url.startsWith("blob:") || url.startsWith("data:")) return;

  // ── M3U8 / HLS direct stream ───────────────────────────────────────────────
  // Raw M3U8 URLs can't be scanned with yt-dlp -J. Show an HLS-ready card
  // and let the user start the download directly — no /info call needed.
  const isM3U8 = /\.m3u8(\?|$|#)/i.test(url) ||
                 /\/hls\//i.test(url) ||
                 /index-v\d+-a\d+\.m3u8/i.test(url);

  if (isM3U8) {
    scannedMediaData = { title: "HLS Stream", thumbnail: "", duration: "", formats: [] };

    // Build a friendly referer label
    let refererHost = "";
    if (currentPageReferer) {
      try { refererHost = new URL(currentPageReferer).hostname; } catch (_) {}
    }

    // Populate preview card
    previewTitle.textContent  = "HLS Stream (M3U8)";
    previewThumb.src          = "icons/icon-128.png";
    previewDuration.textContent = refererHost ? `🌐 ${refererHost}` : "Live / Stream";

    // Update the source badge to show HLS
    if (previewSource) {
      previewSource.textContent = "📡 HLS Stream";
      previewSource.className   = "badge badge-success";
    }

    previewCard.classList.remove("hidden");

    // Label the download button to reassure the user
    if (btnStartDownload) {
      btnStartDownload.innerHTML = `<span>📡 Download HLS Stream</span>`;
    }

    showToast(
      refererHost
        ? `⚡ HLS stream ready — referer: ${refererHost}`
        : `⚡ HLS/M3U8 stream detected — ready to download!`
    );
    return;
  }
  // ──────────────────────────────────────────────────────────────────────────

  // Restore download button text for normal URLs
  if (btnStartDownload) {
    btnStartDownload.innerHTML = `<span>🚀 Start Accelerated Download</span>`;
  }
  if (previewSource) {
    previewSource.textContent = "Detected";
    previewSource.className   = "badge badge-info";
  }

  if (!isBackendOnline) {
    const ok = await checkServerHealth();
    if (!ok) {
      showToast("Backend offline — please run python backend/app.py");
      return;
    }
  }

  scanSpinner.classList.remove("hidden");
  scanBtnText.textContent = "Scanning...";
  btnScanMedia.disabled = true;

  try {
    // Include the page referer so /info can pass --referer to yt-dlp for
    // restricted sites (e.g. vixeo.io and similar HLS-gated platforms)
    let infoUrl = `${API_BASE}/info?url=${encodeURIComponent(url)}`;
    if (currentPageReferer && currentPageReferer.startsWith("http")) {
      infoUrl += `&referer=${encodeURIComponent(currentPageReferer)}`;
    }
    const res = await fetch(infoUrl);
    if (res.ok) {
      const data = await res.json();
      scannedMediaData = data;
      renderPreview(data);
      showToast(`Media loaded: ${data.title ? data.title.slice(0, 25) + "..." : "Ready to download"} ⚡`);
    } else {
      const errData = await res.json().catch(() => ({}));

      // ── Scan failed — check if there are captured HLS streams for this tab ──
      // This handles the case where the page has a blob: URL video (vixeo.io etc.)
      // and yt-dlp can't extract it, but background.js has captured the stream.
      const hlsHandled = await tryFallbackToHLSStreams(url);
      if (!hlsHandled) {
        showToast(errData.error || "Failed to extract media information ⚠️");
        previewCard.classList.add("hidden");
        scannedMediaData = null;
      }
    }
  } catch (err) {
    console.error("Scan error:", err);

    // Network error — also check HLS streams before giving up
    const hlsHandled = await tryFallbackToHLSStreams(url);
    if (!hlsHandled) {
      showToast("Network error while scanning media ⚠️");
      previewCard.classList.add("hidden");
      scannedMediaData = null;
    }
  } finally {
    scanSpinner.classList.add("hidden");
    scanBtnText.textContent = "🔍 Scan Media";
    btnScanMedia.disabled = false;
  }
}

/**
 * When /info scan fails, check if background.js captured HLS streams for
 * the active tab. If yes → switch to M3U8 mode. If no → show wait message
 * (only when currentPageReferer is set, i.e. came from a blob-URL video click).
 * Returns true if handled, false if caller should show generic error.
 */
async function tryFallbackToHLSStreams(scannedUrl) {
  if (!chrome || !chrome.tabs || !chrome.storage) return false;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return false;

    const tabKey = `streams_tab_${tab.id}`;
    return new Promise((resolve) => {
      chrome.storage.local.get([tabKey], (tabRes) => {
        const streams = Array.isArray(tabRes[tabKey]) ? tabRes[tabKey] : [];
        const fresh   = streams.filter((s) => Date.now() - (s.timestamp || 0) < 30 * 60 * 1000);

        if (fresh.length > 0) {
          // ✅ Streams found — switch to M3U8 mode
          mediaUrlInput.value = fresh[0].url;
          currentPageReferer  = fresh[0].pageUrl || currentPageReferer;
          triggerScan(fresh[0].url);
          renderDetectedStreams(streams, tab.id);
          resolve(true);
        } else if (currentPageReferer) {
          // HLS page but video not played yet — show instructions
          showHLSWaitMessage(currentPageReferer);
          resolve(true);
        } else {
          resolve(false);  // Plain scan failure — show normal error
        }
      });
    });
  } catch (_) {
    return false;
  }
}


function renderPreview(data) {
  previewTitle.textContent = data.title || "Media File";
  previewThumb.src = data.thumbnail || "icons/icon-128.png";
  previewDuration.textContent = data.duration || "";
  previewCard.classList.remove("hidden");

  if (data.formats && data.formats.length > 0) {
    qualitySelect.innerHTML = `<option value="best" selected>Best Available</option>`;
    data.formats.forEach((f) => {
      const opt = document.createElement("option");
      opt.value = f.resolution || `${f.height}p`;
      opt.textContent = `${f.resolution || f.height + "p"} (${f.ext || "mp4"})`;
      qualitySelect.appendChild(opt);
    });
  }
}

// ============================================================
// 4. START DOWNLOAD & ENHANCED LIVE QUEUE
// ============================================================

async function startDownload() {
  const url = mediaUrlInput ? mediaUrlInput.value.trim() : "";
  if (!url) {
    highlightEmptyInput(mediaUrlInput, "⚠️ Enter or scan a video/audio URL first!");
    return;
  }

  if (!isBackendOnline) {
    const ok = await checkServerHealth();
    if (!ok) {
      showToast("Backend offline — start python backend/app.py");
      return;
    }
  }

  const payload = {
    url: url,
    format: formatSelect.value,
    quality: qualitySelect.value,
    connections: parseInt(connectionsSlider.value, 10),
    title: scannedMediaData ? scannedMediaData.title : "",
    thumbnail_url: scannedMediaData ? scannedMediaData.thumbnail : "",
    // Pass the page referer so yt-dlp can set --referer for restricted sites
    referer: currentPageReferer || "",
  };

  btnStartDownload.disabled = true;
  btnStartDownload.innerHTML = `<span>⏳ Enqueueing...</span>`;

  try {
    const res = await fetch(`${API_BASE}/download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      const data = await res.json();
      currentTaskId = data.task_id;

      if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({
          activeTask: {
            taskId: currentTaskId,
            title: payload.title || "Downloading Media...",
            url: url,
            startedAt: Date.now(),
          },
        });
      }

      showToast(`⚡ Download queued (Position #${data.queue_position})`);
      switchTab("tab-queue");
      listenToProgressStream(currentTaskId, payload.title || url);
    } else {
      const err = await res.json();
      showToast(`Error: ${err.error || "Failed to start download"}`);
    }
  } catch (err) {
    showToast(`Network error: ${err.message}`);
  } finally {
    btnStartDownload.disabled = false;
    btnStartDownload.innerHTML = `<span>🚀 Start Accelerated Download</span>`;
  }
}

async function restoreActiveQueue() {
  // Query backend for currently active or queued tasks
  if (isBackendOnline) {
    try {
      const res = await fetch(`${API_BASE}/active-tasks`, { signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        const data = await res.json();
        if (data.tasks && data.tasks.length > 0) {
          queueBadge.classList.remove("hidden");
          queueBadge.textContent = String(data.tasks.length);
          emptyQueue.classList.add("hidden");

          for (const task of data.tasks) {
            currentTaskId = task.task_id;
            listenToProgressStream(task.task_id, task.title);
          }
          return;
        }
      }
    } catch (e) {
      console.warn("Could not query active tasks from server:", e);
    }
  }

  // Fallback to extension storage
  const storageObj = typeof browser !== "undefined" && browser.storage ? browser.storage.local : (chrome && chrome.storage ? chrome.storage.local : null);
  if (storageObj) {
    storageObj.get(["activeTask"], (res) => {
      if (res.activeTask && res.activeTask.taskId) {
        currentTaskId = res.activeTask.taskId;
        listenToProgressStream(currentTaskId, res.activeTask.title);
      }
    });
  }
}

function listenToProgressStream(taskId, fallbackTitle = "Media Download") {
  if (activeEventSource) {
    activeEventSource.close();
  }

  emptyQueue.classList.add("hidden");
  queueBadge.classList.remove("hidden");
  queueBadge.textContent = "1";

  let card = document.getElementById(`task-card-${taskId}`);
  if (!card) {
    card = document.createElement("div");
    card.className = "queue-card";
    card.id = `task-card-${taskId}`;
    card.innerHTML = `
      <div class="queue-card-header">
        <h4 class="queue-title">${escapeHtml(fallbackTitle)}</h4>
        <span class="badge-status queued" id="status-badge-${taskId}">Queued</span>
      </div>
      <div class="progress-container">
        <div class="progress-bar-wrap">
          <div class="progress-bar-fill" id="progress-fill-${taskId}"></div>
        </div>
      </div>
      <div class="queue-stats-grid">
        <div class="stat-item">
          <span class="stat-icon">⚡</span>
          <div>
            <div class="stat-label">Speed</div>
            <div class="stat-value stat-speed" id="speed-${taskId}">0 KiB/s</div>
          </div>
        </div>
        <div class="stat-item">
          <span class="stat-icon">💾</span>
          <div>
            <div class="stat-label">File Size</div>
            <div class="stat-value stat-size" id="size-${taskId}">--</div>
          </div>
        </div>
        <div class="stat-item">
          <span class="stat-icon">📊</span>
          <div>
            <div class="stat-label">Progress</div>
            <div class="stat-value stat-percent" id="percent-${taskId}">0.0%</div>
          </div>
        </div>
        <div class="stat-item">
          <span class="stat-icon">⏳</span>
          <div>
            <div class="stat-label">Time Remaining</div>
            <div class="stat-value stat-eta" id="eta-${taskId}">--</div>
          </div>
        </div>
      </div>
      <div class="queue-card-actions">
        <button class="btn-cancel-prominent" id="btn-cancel-${taskId}">
          <span>✕</span><span>Cancel Download</span>
        </button>
      </div>
    `;
    queueList.prepend(card);

    document.getElementById(`btn-cancel-${taskId}`).addEventListener("click", () => {
      cancelTask(taskId);
    });
  }

  const fillEl = document.getElementById(`progress-fill-${taskId}`);
  const statusBadge = document.getElementById(`status-badge-${taskId}`);
  const speedEl = document.getElementById(`speed-${taskId}`);
  const sizeEl = document.getElementById(`size-${taskId}`);
  const percentEl = document.getElementById(`percent-${taskId}`);
  const etaEl = document.getElementById(`eta-${taskId}`);

  activeEventSource = new EventSource(`${API_BASE}/progress-stream/${taskId}`);

  activeEventSource.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      const status = data.status || "downloading";
      const pct = typeof data.percent === "number" ? data.percent : parseFloat(data.percent || 0);
      const speed = data.speed || "0 KiB/s";
      const size = data.size || "--";
      const eta = data.eta || "--";

      if (fillEl) fillEl.style.width = `${Math.min(100, Math.max(0, pct))}%`;
      if (percentEl) percentEl.textContent = `${pct.toFixed(1)}%`;
      if (speedEl) speedEl.textContent = speed;
      if (sizeEl) sizeEl.textContent = size;
      if (etaEl) etaEl.textContent = eta;



      if (status === "queued") {
        if (statusBadge) {
          statusBadge.className = "badge-status queued";
          statusBadge.textContent = `Queued (#${data.queue_position || 1})`;
        }
      } else if (status === "downloading") {
        if (statusBadge) {
          statusBadge.className = "badge-status downloading";
          statusBadge.textContent = "⚡ Downloading";
        }
      } else if (status === "completed") {
        if (statusBadge) {
          statusBadge.className = "badge-status completed";
          statusBadge.textContent = "✅ Completed";
        }
        if (fillEl) fillEl.style.width = "100%";
        if (percentEl) percentEl.textContent = "100%";
        if (speedEl) speedEl.textContent = "Done";
        if (sizeEl) sizeEl.textContent = data.size || "Saved";
        if (etaEl) etaEl.textContent = "00:00";
        activeEventSource.close();
        clearActiveTaskStorage();
        showToast("✅ Download completed successfully!");
        // Remove the queue card after a short delay so user can see the completed status
        setTimeout(() => {
          const cardEl = document.getElementById(`task-card-${taskId}`);
          if (cardEl) {
            cardEl.style.transition = "opacity 0.5s ease, transform 0.5s ease";
            cardEl.style.opacity = "0";
            cardEl.style.transform = "translateY(-8px)";
            setTimeout(() => {
              cardEl.remove();
              // Show empty queue placeholder if no more cards
              if (queueList.querySelectorAll(".queue-card").length === 0) {
                emptyQueue.classList.remove("hidden");
                queueBadge.classList.add("hidden");
              }
            }, 500);
          }
        }, 3000);
      } else if (status === "failed" || status === "cancelled") {
        if (statusBadge) {
          statusBadge.className = `badge-status ${status}`;
          statusBadge.textContent = status === "failed" ? "❌ Failed" : "⏸ Cancelled";
        }
        activeEventSource.close();
        clearActiveTaskStorage();
      }
    } catch (e) {
      console.error("Error parsing progress stream:", e);
    }
  };

  activeEventSource.onerror = () => {
    if (activeEventSource) activeEventSource.close();
  };
}

async function cancelTask(taskId) {
  try {
    const res = await fetch(`${API_BASE}/cancel/${taskId}`, { method: "POST" });
    if (res.ok) {
      showToast("Download cancelled");
      const statusBadge = document.getElementById(`status-badge-${taskId}`);
      if (statusBadge) {
        statusBadge.className = "badge-status cancelled";
        statusBadge.textContent = "⏸ Cancelled";
      }
      if (activeEventSource) activeEventSource.close();
      clearActiveTaskStorage();
    }
  } catch (err) {
    showToast("Failed to cancel download");
  }
}

function clearActiveTaskStorage() {
  if (chrome && chrome.storage && chrome.storage.local) {
    chrome.storage.local.remove(["activeTask"]);
  }
  queueBadge.classList.add("hidden");
}

// ============================================================
// 5. HISTORY TAB & ACTIONS
// ============================================================

async function loadHistory(page = 1) {
  if (!isBackendOnline) {
    const ok = await checkServerHealth();
    if (!ok) {
      historyList.innerHTML = `<div class="empty-state"><p>Connect backend to view download history.</p></div>`;
      return;
    }
  }

  historyCurrentPage = page;
  const q = historySearch.value.trim();
  const status = historyFilter.value;

  let url = `${API_BASE}/history?page=${page}&limit=10`;
  if (q) url += `&q=${encodeURIComponent(q)}`;
  if (status && status !== "all") url += `&status=${encodeURIComponent(status)}`;

  try {
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      renderHistoryItems(data.items, data.total, data.page, data.limit);
    }
  } catch (err) {
    console.error("Failed to fetch history:", err);
  }
}

function renderHistoryItems(items, total, page, limit) {
  historyCount.textContent = `${total} items`;
  const totalPages = Math.max(1, Math.ceil(total / limit));
  pageInfo.textContent = `Page ${page} of ${totalPages}`;

  btnPrevPage.disabled = page <= 1;
  btnNextPage.disabled = page >= totalPages;

  if (!items || items.length === 0) {
    historyList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📜</div>
        <h3>No History Records</h3>
        <p>Your downloaded media records will appear here.</p>
      </div>
    `;
    return;
  }

  historyList.innerHTML = "";
  items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "history-item";

    const statusClass = (item.status || "completed").toLowerCase();
    const sizeStr = item.file_size_mb ? `${item.file_size_mb.toFixed(1)} MB` : "";

    card.innerHTML = `
      <div class="history-item-main">
        <div class="history-item-title">${escapeHtml(item.title)}</div>
        <span class="badge-status ${statusClass}">${item.status}</span>
      </div>
      <div class="history-item-meta">
        <span>🕒 ${item.downloaded_at || "Recent"}</span>
        <span>•</span>
        <span>🎬 ${item.file_format.toUpperCase()} (${item.quality || "best"})</span>
        ${sizeStr ? `<span>•</span><span>💾 ${sizeStr}</span>` : ""}
      </div>
      <div class="history-actions">
        ${
          item.file_path
            ? `<button class="btn-action-small btn-open-folder" data-path="${escapeHtml(item.file_path)}" title="Open file location">📂 Open Folder</button>`
            : ""
        }
        <button class="btn-action-small btn-redownload" data-url="${escapeHtml(item.source_url)}" data-format="${escapeHtml(item.file_format)}" data-quality="${escapeHtml(item.quality)}" title="Download again">🔁 Re-download</button>
        <button class="btn-action-small btn-delete-item" data-id="${item.id}" title="Remove record">🗑</button>
      </div>
    `;

    historyList.appendChild(card);
  });

  document.querySelectorAll(".btn-open-folder").forEach((btn) => {
    btn.addEventListener("click", () => openFolder(btn.getAttribute("data-path")));
  });

  document.querySelectorAll(".btn-redownload").forEach((btn) => {
    btn.addEventListener("click", () => {
      mediaUrlInput.value = btn.getAttribute("data-url");
      formatSelect.value = btn.getAttribute("data-format") || "mp4";
      qualitySelect.value = btn.getAttribute("data-quality") || "best";
      switchTab("tab-media");
      triggerScan(btn.getAttribute("data-url"));
    });
  });

  document.querySelectorAll(".btn-delete-item").forEach((btn) => {
    btn.addEventListener("click", () => deleteHistoryEntry(btn.getAttribute("data-id")));
  });
}

async function openFolder(filePath) {
  try {
    const res = await fetch(`${API_BASE}/open-folder`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file_path: filePath }),
    });
    if (res.ok) {
      showToast("📂 Opened file in explorer");
    } else {
      const err = await res.json();
      showToast(`Error: ${err.error || "Cannot open folder"}`);
    }
  } catch (e) {
    showToast("Failed to open folder");
  }
}

async function deleteHistoryEntry(id) {
  try {
    const res = await fetch(`${API_BASE}/history/${id}`, { method: "DELETE" });
    if (res.ok) {
      showToast("Record removed");
      loadHistory(historyCurrentPage);
    }
  } catch (e) {
    showToast("Failed to delete record");
  }
}

async function clearAllHistory() {
  if (!confirm("Are you sure you want to clear all download history?")) return;
  try {
    const res = await fetch(`${API_BASE}/history/clear`, { method: "POST" });
    if (res.ok) {
      showToast("History cleared");
      loadHistory(1);
    }
  } catch (e) {
    showToast("Failed to clear history");
  }
}

// ============================================================
// 6. SETTINGS TAB & PERSISTENCE
// ============================================================

async function loadAndApplySettings() {
  let settings = null;
  if (isBackendOnline) {
    try {
      const res = await fetch(`${API_BASE}/settings`);
      if (res.ok) {
        settings = await res.json();
        if (chrome && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ userSettings: settings });
        }
      }
    } catch (e) {
      console.warn("Could not fetch settings from backend:", e);
    }
  }

  if (!settings && chrome && chrome.storage && chrome.storage.local) {
    const stored = await chrome.storage.local.get(["userSettings"]);
    if (stored.userSettings) settings = stored.userSettings;
  }

  if (settings) {
    if (settingConcurrent && settings.max_concurrent_downloads) {
      settingConcurrent.value = String(settings.max_concurrent_downloads);
    }
    if (settingConnections && settings.default_connections) {
      settingConnections.value = String(settings.default_connections);
      connectionsSlider.value = String(settings.default_connections);
      speedBadge.textContent = `⚡ ${settings.default_connections}x Connections`;
    }
    if (settingFormat && settings.default_format) {
      settingFormat.value = settings.default_format;
      formatSelect.value = settings.default_format;
    }
    if (settingQuality && settings.default_quality) {
      settingQuality.value = settings.default_quality;
      qualitySelect.value = settings.default_quality;
    }
    const customDir = settings.download_dir || "";
    if (settingDownloadDirText) {
      settingDownloadDirText.textContent = customDir || "System Downloads";
      settingDownloadDirText.title = customDir || "System Downloads";
    }
    if (settingDownloadDir) {
      settingDownloadDir.value = customDir;
    }
    if (settingCustomDirDisplay) {
      settingCustomDirDisplay.textContent = customDir || "Default: System Downloads";
      settingCustomDirDisplay.title = customDir || "Default: System Downloads";
    }
    if (btnResetFolder) {
      btnResetFolder.classList.toggle("hidden", !customDir);
    }
  }
}

async function saveSettings() {
  const payload = {
    max_concurrent_downloads: parseInt(settingConcurrent.value, 10),
    default_connections: parseInt(settingConnections.value, 10),
    default_format: settingFormat.value,
    default_quality: settingQuality.value,
    download_dir: settingDownloadDir ? settingDownloadDir.value.trim() : "",
  };

  connectionsSlider.value = String(payload.default_connections);
  speedBadge.textContent = `⚡ ${payload.default_connections}x Connections`;
  formatSelect.value = payload.default_format;
  qualitySelect.value = payload.default_quality;
  if (settingDownloadDirText) {
    settingDownloadDirText.textContent = payload.download_dir || "System Downloads";
    settingDownloadDirText.title = payload.download_dir || "System Downloads";
  }
  if (settingCustomDirDisplay) {
    settingCustomDirDisplay.textContent = payload.download_dir || "Default: System Downloads";
    settingCustomDirDisplay.title = payload.download_dir || "Default: System Downloads";
  }
  if (btnResetFolder) {
    btnResetFolder.classList.toggle("hidden", !payload.download_dir);
  }

  if (chrome && chrome.storage && chrome.storage.local) {
    await chrome.storage.local.set({ userSettings: payload });
  }

  if (isBackendOnline) {
    try {
      const res = await fetch(`${API_BASE}/settings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const savedData = await res.json();
        if (savedData && savedData.settings && savedData.settings.download_dir && settingDownloadDirText) {
          settingDownloadDirText.textContent = savedData.settings.download_dir;
          settingDownloadDirText.title = savedData.settings.download_dir;
        }
        showToast("💾 Settings saved successfully!");
        return;
      }
    } catch (e) {
      console.warn("Error saving settings to backend:", e);
    }
  }

  showToast("💾 Settings saved locally!");
}

// ============================================================
// 7. UTILITIES
// ============================================================

function escapeHtml(str) {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}
